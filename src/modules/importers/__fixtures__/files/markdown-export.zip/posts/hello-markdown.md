---
title: Hello, Markdown
slug: hello-markdown
date: 2024-03-07
tags: [writing, tools]
redirect_from:
  - /old/hello/
  - /2024/hello-markdown/
---

# Hello, Markdown

This is a real post written in Markdown, with an image and some code.

An inline markdown image (renders inside a paragraph):

![A landscape](https://cdn.example.com/landscape.jpg "A wide landscape")

A raw HTML figure (Obsidian/Hugo allow inline HTML — becomes a native image block):

<figure><img src="https://cdn.example.com/figure.jpg" alt="A framed figure"/><figcaption>A framed figure.</figcaption></figure>

Here's a snippet:

```js
console.log("hello from markdown");
```

- first point
- second point
