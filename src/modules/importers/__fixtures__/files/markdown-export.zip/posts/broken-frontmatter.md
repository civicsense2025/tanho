---
title: [unterminated
tags: oops
---

The body is fine even though the frontmatter is not.
