---
title: "Migrating from Hugo"
date: 2024-03-14T09:00:00-05:00
aliases:
  - /blog/migrating-hugo/
  - /posts/hugo/
tags:
  - migration
  - hugo
---

Moving content from Hugo keeps the **aliases** as redirects.

> A blockquote to prove richtext survives.
